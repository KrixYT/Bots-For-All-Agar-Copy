var app = require('http').createServer()
var io = require('socket.io')(app);
var fs = require('fs');
var change = false;
var databuf = null;
var s = null;
var connected = false;
var idf = 0;
require("colors");

app.listen(8081);
function load() {
    var figlet = require('figlet');
    figlet('GotaFeederBots', function (err, data) {
        console.log(('Loading').green);	
        console.log(('Gota Feeder Bots').green);	
        console.log(('').green);				
		console.log(('Suscribe To KrixYT').green);		
		console.log(('').green);		
		console.log(('To start, join a game with the botting script installed').green);		
        console.log('');							
    });
}
io.on('connection', function(socket) {
	var cli = {};
  socket.on('login', function(data) {	
	cli = data
    socket.room = data.uuid;
    socket.join(data.uuid);
    if (data.type == "server") {      
      io.sockets.in(socket.room).emit("force-login", "server-booted-up");
	  idf = 0;
    }
  });
  socket.on('pos', function(data) {
    io.sockets.in(socket.room).emit('pos', data);	
  }); 
    socket.on('size', function(data) {	  
    io.sockets.in(socket.room).emit('pos', data);	
  }); 
  socket.on('close', function(data) {   
	clearInterval(s);
	socket.room = null;
    socket.leave();
	socket.conn.close();
	s = null;	
  });  
  socket.on('disconnect', function(data) {    
	clearInterval(s);
	socket.room = null;
    socket.leave();
	socket.conn.close();
	s = null;	
  });   
  function send(val) {	  
	  idf++;
	  if (idf == 1) { // 2 <= 1
		  s = setInterval(function() {
			if (change == false) {				
				io.sockets.in(socket.room).emit('buf', databuf);				
			}else{				
				change = true;
				clearInterval(s);				
			}			
		}, 1000);		
	} 	
}    
  socket.on('buf', function(data) {  
	databuf = data;
	send(1);
  });
  socket.on('cmd', function(data) {
	  if (data.id != 0) {
		  if (connected == false) {
    console.log(('A new user has connected:').green);
	console.log(('  Nick: ' + data.nick).green);
	console.log(('  ID: ' + data.id).green);
	console.log(('  Server: ' + data.ip).green);
	console.log(('  Gota Version: ' + data.version).green);
	connected = true
	  }
    io.sockets.in(socket.room).emit('cmd', data);

	  }
  }); 
  socket.on("spawn-count", function(data) {
    io.sockets.in(socket.room).emit("spawn-count", data);
    });
  socket.emit("force-login", "startup"); 
});
load();
require("./cmd.js");