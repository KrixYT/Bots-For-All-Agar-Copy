const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function change (uu) {
		
	var fs  = require("fs");

}


rl.on('line', (line) => {
   
});